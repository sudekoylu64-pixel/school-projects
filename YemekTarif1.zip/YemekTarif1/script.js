function filterMeals(category, event) {
  // Yemekleri filtreleme
  const meals = document.querySelectorAll(".meal-card");
  meals.forEach((meal) => {
    if (category === "all" || meal.classList.contains(category)) {
      meal.style.display = "block";
    } else {
      meal.style.display = "none";
    }
  });

  // Aktif butonu ayarla
  const buttons = document.querySelectorAll(".category-buttons button");
  buttons.forEach((btn) => btn.classList.remove("active"));
  if (event) {
    event.target.classList.add("active");
  }
}

// Sayfa yüklendiğinde ilk olarak "Tüm"ü aktif hale getir
window.onload = () => {
  filterMeals("all"); // "Tüm"ü göster
};

function searchMeals() {
  const input = document.getElementById("searchInput").value.toLowerCase();
  const meals = document.querySelectorAll(".meal-card");

  meals.forEach((meal) => {
    const title = meal.querySelector("h3").innerText.toLowerCase();
    if (title.includes(input)) {
      meal.style.display = "block";
    } else {
      meal.style.display = "none";
    }
  });
}
